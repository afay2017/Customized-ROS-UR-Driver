# ltchin_packing

Control for packing demo for Chin, ICRA 2019 


## Dependecies
* [MoveIt! package](http://docs.ros.org/kinetic/api/moveit_tutorials/html/doc/getting_started/getting_started.html)
* [Baxter Interface](http://sdk.rethinkrobotics.com/wiki/Workstation_Setup#Step_3:_Create_Baxter_Development_Workspace)
* [aux_gripper](https://github.com/mit-drl/aux_gripper)
* [moveit_planner](https://github.com/mit-drl/moveit_planner)
* [pcl_planar_segmentation](https://github.com/mit-drl/pcl_planar_segmentation)
